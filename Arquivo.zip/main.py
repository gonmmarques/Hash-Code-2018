import project

if __name__ == '__main__':
    project.main()
